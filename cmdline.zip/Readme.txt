Command line Here for Windows NT/2000/XP
by Aubrey Hall - whoamint.dk3.com - aubhall@yahoo.com
Last updated: 16-03-2000

This adds an item named "Command Line Here" to the context menus of folders
in Windows Explorer which, when selected, opens a command prompt window with
the folder as the current directory.

Under Windows NT/2000/XP

By default, it uses %SystemRoot%\system32\cmd.exe as the command interpreter.

Under Windows '95/98/ME

By default, it uses c:\windows\command.com as the command interpreter.
